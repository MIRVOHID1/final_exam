import "./Featured.scss";

const Featured = () => {
    return (
        <div></div>
    );
}

export default Featured;